# Student-Record-Management-System
The objective of the Student Record Management System is to help in maintenance and management of student records. The Project contains Admin side and Student side. 
In this project all the functions has to be performed from Admin side.

## Featuers of Project
Login as Admin

*	Department (Add, Edit, Delete)
*	Course combination with department (Add, Update, Delete)
*	Subject combination with course (Add, Update, Delete)
*	Student (Add, View, Update, Delete)
*	Marks (Add, Edit)<br />

Login as Student

*	View Profile<br />
*	View Marks<br />

Logout

## Installation
*	Install XAMPP
*	Open XAMPP Control panel and start [apache] and [mysql]
*	Download the project zip file
*	Extract the file and copy “SRMS” folder 
*	Paste inside root directory xampp/htdocs/
*	Open PHPMyAdmin (http://localhost/phpmyadmin)
*	Create a database named ‘srms’
*	Import srms.sql file (given in zip package)
*	Open the browser and type localhost/SRMS/ 


