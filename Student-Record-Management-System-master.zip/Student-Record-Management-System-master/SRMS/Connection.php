<?php

$con=mysqli_connect("localhost","root","","srms");

if(mysqli_connect_error())
{
    echo "Cannot Connect";
}
?>